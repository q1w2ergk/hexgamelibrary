----------------------------
addappid(2397300)
addappid(2397301, 1, "0d49aa268c5fc78babcfe220c4828bd7bbc422ae09419958a82240f57b82e161")
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(4355970)
addappid(4355970, 1, "a1a3a30f2d8cabc41059d866af336784462840865d6bcbc5eb9962fcb794dc42")
--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
----------------------------