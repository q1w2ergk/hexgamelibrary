-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(3008670,0,"05af48230917e5f7df38d99935306907947f276d13191bc0853a0338fc295fa7")
